/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;
import excepciones.TiempoExcedidoException;
/**
 *
 * @author HP1
 */
public class ArchivoDescarga implements Runnable {

    private String nombreArchivo;
    private int tiempoLimite;

    public ArchivoDescarga(String nombreArchivo, int tiempoLimite) {
        this.nombreArchivo = nombreArchivo;
        this.tiempoLimite = tiempoLimite;
    }

    @Override
    public void run() {

        try {
            System.out.println("Iniciando descarga: " + nombreArchivo);

            for (int i = 1; i <= 10; i++) {

                Thread.sleep(1000);

                System.out.println(
                    nombreArchivo + " - Progreso: " + (i * 10) + "%"
                );

                if (i >= tiempoLimite) {
                    throw new TiempoExcedidoException(
                        "La descarga de " + nombreArchivo
                        + " excedio el tiempo limite."
                    );
                }
            }

            System.out.println(
                "Descarga completada: " + nombreArchivo
            );

        } catch (InterruptedException e) {

            System.out.println(
                "La descarga fue interrumpida: " + nombreArchivo
            );

        } catch (TiempoExcedidoException e) {

            System.out.println(e.getMessage());
        }
    }
}  