/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.modulodescargas;

import controlador.DescargaController;
import java.util.Scanner;

public class ModuloDescargas {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);
        DescargaController controlador = new DescargaController();

        System.out.println("=================================");
        System.out.println("       MODULO DE DESCARGAS");
        System.out.println("=================================");

        System.out.print("Ingrese el nombre del archivo: ");
        String nombre = teclado.nextLine();

        System.out.print("Ingrese el tiempo limite en segundos: ");
        int tiempo = teclado.nextInt();

        System.out.println();
        System.out.println("Iniciando descarga...");
        System.out.println();

        controlador.iniciarDescarga(nombre, tiempo);

        teclado.close();
    }
}