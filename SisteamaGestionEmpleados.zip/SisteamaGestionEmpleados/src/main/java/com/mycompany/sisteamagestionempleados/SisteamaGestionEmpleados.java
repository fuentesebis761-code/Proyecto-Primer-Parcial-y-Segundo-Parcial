/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sisteamagestionempleados;
import Controlador.EmpleadoController;

/**
 *
 * @author HP1
 */
public class SisteamaGestionEmpleados {

    public static void main(String[] args) {

        EmpleadoController controller = new EmpleadoController();

        boolean registrado = controller.registrarEmpleado(
                "001",
                "Carlos",
                "Tegucigalpa",
                "Colonia Kennedy",
                12000,
                2000
        );

        if (registrado) {
            System.out.println("Empleado registrado correctamente.");
        } else {
            System.out.println("Error al registrar el empleado.");
        }
    }
}