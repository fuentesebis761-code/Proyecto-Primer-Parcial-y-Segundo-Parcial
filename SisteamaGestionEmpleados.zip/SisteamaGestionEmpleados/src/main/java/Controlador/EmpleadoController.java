/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import modelo.Empleado;
import modelo.Direccion;
import persistencia.ArchivoEmpleadoDAO;
import java.io.IOException;

/**
 *
 * @author HP1
 */
public class EmpleadoController {

    private ArchivoEmpleadoDAO dao;

    public EmpleadoController() {
        this.dao = new ArchivoEmpleadoDAO();
    }

    public boolean registrarEmpleado(String id, String nombre,
            String ciudad, String calle,
            double salario, double bono) {

        try {
            Direccion dir = new Direccion(ciudad, calle);

            Empleado emp = new Empleado(
                    id, nombre, dir, salario, bono
            );

            dao.guardarEmpleado(emp);

            return true;

        } catch (IOException e) {
            System.err.println("Error de E/S: " + e.getMessage());
            return false;
        }
    }
}