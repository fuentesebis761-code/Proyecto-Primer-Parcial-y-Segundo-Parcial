/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.procesamientoasincrono;

import Controlador.TransaccionController;
import modelo.CuentaBancaria;
import vista.TransaccionForm;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class ProcesamientoAsincrono {

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            try {
                UIManager.setLookAndFeel(
                        "javax.swing.plaf.nimbus.NimbusLookAndFeel"
                );
            } catch (Exception e) {
                System.out.println(
                        "Se utilizará el diseño predeterminado."
                );
            }

            CuentaBancaria cuenta = new CuentaBancaria(500.00);

            TransaccionForm formulario = new TransaccionForm();

            new TransaccionController(cuenta, formulario);

            formulario.setVisible(true);
        });
    }
}
