/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;
import modelo.CuentaBancaria;
import modelo.ProcesoRetiroHilo;
import vista.TransaccionForm;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
/**
 *
 * @author HP1
 */
public class TransaccionController {

    private CuentaBancaria cuenta;
    private TransaccionForm vista;

    public TransaccionController(
            CuentaBancaria cuenta,
            TransaccionForm vista) {

        this.cuenta = cuenta;
        this.vista = vista;

        this.vista.getBtnProcesar().addActionListener(e -> procesarRetiro());
    }

    private void procesarRetiro() {

        String texto = vista.getTxtMontoRetirar().getText().trim();

        if (texto.isEmpty()) {
            JOptionPane.showMessageDialog(
                    vista,
                    "Ingrese el monto que desea retirar."
            );
            return;
        }

        double monto;

        try {
            monto = Double.parseDouble(texto);

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(
                    vista,
                    "Ingrese un monto numérico válido."
            );
            return;
        }

        if (!Double.isFinite(monto) || monto <= 0) {
            JOptionPane.showMessageDialog(
                    vista,
                    "El monto debe ser un número mayor que cero."
            );
            return;
        }

        vista.setProcesando(true);
        vista.setEstado("Procesando retiro...");

        ProcesoRetiroHilo proceso = new ProcesoRetiroHilo(
                cuenta,
                monto,
                new ProcesoRetiroHilo.ProcesoListener() {

            @Override
            public void onInicio() {
                // El proceso ha comenzado.
            }

            @Override
            public void onExito(double nuevoSaldo) {
                SwingUtilities.invokeLater(() -> {
                    vista.setEstado(
                            String.format(
                                    "Retiro exitoso. Saldo: $%.2f",
                                    nuevoSaldo
                            )
                    );

                    vista.setProcesando(false);
                    vista.getTxtMontoRetirar().setText("");
                });
            }

            @Override
            public void onError(String error) {
                SwingUtilities.invokeLater(() -> {
                    vista.setEstado(error);
                    vista.setProcesando(false);
                });
            }
        });

        Thread hilo = new Thread(proceso);
        hilo.start();
    }
}

