/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;
import Excepciones.SaldoInsuficienteException;

/**
 *
 * @author HP1
 */
public class CuentaBancaria {

    private double saldo;

    public CuentaBancaria(double saldoInicial) {
        this.saldo = saldoInicial;
    }

    public synchronized void retirar(double monto)
            throws SaldoInsuficienteException {

        if (monto <= 0) {
            throw new IllegalArgumentException(
                    "El monto debe ser mayor que cero."
            );
        }

        if (monto > saldo) {
            throw new SaldoInsuficienteException(
                    "Saldo insuficiente.",
                    monto - saldo
            );
        }

        saldo -= monto;
    }

    public synchronized double getSaldo() {
        return saldo;
    }
}