/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;
import modelo.Contacto;
import javax.swing.*;
import java.awt.*;

/**
 *
 * @author HP1
 */
public class VentanaContacto extends JFrame {

private JTextField txtNombre;
private JTextField txtTelefono;
private JButton btnProcesar;
private JLabel lblResultado;

public VentanaContacto() {

    setTitle("Registro de Contactos");
    setSize(400, 280);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLocationRelativeTo(null);
    setResizable(false);

    setLayout(new GridLayout(4, 2, 10, 10));

    JLabel lblNombre = new JLabel("Nombre:");
    txtNombre = new JTextField();

    JLabel lblTelefono = new JLabel("Teléfono:");
    txtTelefono = new JTextField();

    btnProcesar = new JButton("Procesar");

    lblResultado = new JLabel("Ingrese los datos del contacto.");

    add(lblNombre);
    add(txtNombre);

    add(lblTelefono);
    add(txtTelefono);

    add(btnProcesar);
    add(new JLabel(""));

    add(new JLabel("Resultado:"));
    add(lblResultado);

    btnProcesar.addActionListener(e -> procesarContacto());
}

private void procesarContacto() {

    String nombre = txtNombre.getText().trim();
    String telefono = txtTelefono.getText().trim();

    if (nombre.isEmpty() || telefono.isEmpty()) {
        JOptionPane.showMessageDialog(
                this,
                "Debe ingresar el nombre y el teléfono."
        );
        return;
    }

    Contacto contacto = new Contacto(nombre, telefono);

    lblResultado.setText(
            "<html>" + contacto.getNombre()
            + "<br>" + contacto.getTelefono()
            + "</html>"
    );
}


}

