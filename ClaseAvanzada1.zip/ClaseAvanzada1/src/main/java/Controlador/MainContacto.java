/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;
import vista.VentanaContacto;
import javax.swing.SwingUtilities;
/**
 *
 * @author HP1
 */
public class MainContacto {

public static void main(String[] args) {

    SwingUtilities.invokeLater(() -> {
        VentanaContacto ventana = new VentanaContacto();
        ventana.setVisible(true);
    });
}

}
