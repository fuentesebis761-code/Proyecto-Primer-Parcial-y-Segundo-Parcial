/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.repositoriogenerico;

/**
 *
 * @author HP1
 */
public class RepositorioGenerico {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
